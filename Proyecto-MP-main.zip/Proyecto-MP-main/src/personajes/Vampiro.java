/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personajes;

import personajes.Esbirro;
import java.util.ArrayList;
import java.util.List;
import equipo.Arma;
import equipo.Armadura;
import habilidades.Debilidad;
import habilidades.Disciplina;
import habilidades.Fortaleza;

/**
 *
 * @author PcCom
 */
public class Vampiro extends Personaje {
    private String nombre;
    private Disciplina Habilidadespecial;
    List<Arma> Armas = new ArrayList();
    private Arma ArmasActivas[] = new Arma[2];
    List<Armadura> Armaduras = new ArrayList();
    private Armadura ArmaduraActiva;
    private Esbirro Esabirros[] = new Esbirro[50];//Esto hay que hacerlo con una lista
    private int oro;
    private int salud;
    private int poder;
    List<Debilidad> Debilidades = new ArrayList();
    List<Fortaleza> Fortalezas = new ArrayList();
    private int edad;
    private int ptosSangre;
    
    public Vampiro(String nombre, int salud, int poder, Arma arma, Armadura armadura, List<Debilidad> deb, List<Fortaleza> fort){
    this.nombre=nombre;
    this.ArmasActivas[1]=arma;
    this.ArmaduraActiva=armadura;
    this.Debilidades=deb;
    this.Fortalezas=fort;
    this.salud=salud;
    this.poder=poder;
}  
}
