/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import practicamp.BaseDatos;
import practicamp.Usuario;

/**
 *
 * @author pcris
 */
public class GUIIniSesionTest {
    
    public GUIIniSesionTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class GUIIniSesion.
     */
    @Test
    public void testMain() {
        GUIIniSesion clase = new GUIIniSesion(new GUIMenuIni());
        BaseDatos base = new BaseDatos();
        int resultado = clase.SignIn(base,"pepe","a");
        int resultadoEsperado = 0;  // contraseña equivocada
        assertEquals(resultadoEsperado,resultado);
        if(resultado != resultadoEsperado){
            fail("The test case is a prototype.");
        }
    }
    
     public void testMain2() {
        GUIIniSesion clase = new GUIIniSesion(new GUIMenuIni());
        BaseDatos base = new BaseDatos();
        int resultado = clase.SignIn(base,"a","a");
        int resultadoEsperado = 1; // 1 = usuario
        assertEquals(resultadoEsperado,resultado);
        if(resultado != resultadoEsperado){
            fail("The test case is a prototype.");
        }
    }  
         public void testMain3() {
        GUIIniSesion clase = new GUIIniSesion(new GUIMenuIni());
        BaseDatos base = new BaseDatos();
        int resultado = clase.SignIn(base,"admin","a");
        int resultadoEsperado = 2; //2 = operador
        assertEquals(resultadoEsperado,resultado);
        if(resultado != resultadoEsperado){
            fail("The test case is a prototype.");
        }
    }
             public void testMain4() {
        GUIIniSesion clase = new GUIIniSesion(new GUIMenuIni());
        BaseDatos base = new BaseDatos();
        int resultado = clase.SignIn(base,"d","d");
        int resultadoEsperado = 3;  //3 = usuario baneado
        assertEquals(resultadoEsperado,resultado);
        if(resultado != resultadoEsperado){
            fail("The test case is a prototype.");
        }
    }
    
}
