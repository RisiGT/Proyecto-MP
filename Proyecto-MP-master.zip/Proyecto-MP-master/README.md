# Proyecto-MP
28/04/2022
  Descargué LLorosNo16JorgePerdonanosHemosPecado-1 y sobre ella actualicé LlorosNo13
  De LlorosNo13 saqué DejaosDeLLoros en el cuál llegué a ver 28 commits

29/04/2022
  Fastidio con un comando todos los commits que no se han hecho en el repositorio del PC de mi casa (cosa que también me paso con el main el 23/04/2022)

30/04/2022
  Marcos y Rubén hacen lo que les sale de la polla para variar y empiezan a modificar cosas de una versión anterior. De este modo los cambios entre esa versión y la última son deshechados completamente. Dicen que van a hacer un push y lo van a juntar todo. Expectante de como crean una nueva rama y no unen un carajo
