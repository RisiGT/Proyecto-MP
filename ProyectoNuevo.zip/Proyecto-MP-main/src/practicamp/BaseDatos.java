/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicamp;

import equipo.Arma;
import equipo.Armadura;
import habilidades.Debilidades;
import habilidades.Disciplina;
import habilidades.Don;
import habilidades.Fortalezas;
import habilidades.Talento;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import personajes.Demonio;
import personajes.Ghoul;
import personajes.Humano;

/**
 *
 * @author PcCom
 */
public class BaseDatos implements Serializable {
    List<Usuario> listausuarios;
    List<Disciplina> listadisciplinas;
    List<Don> listadones;
    List<Talento> listatalentos;
    List<Fortalezas> listafortalezas;
    List<Debilidades> listadebilidades;
    List<Armadura> listaArmaduras;
    List<Arma> listaArmas;
    List<Operador> listaoperadores;
    List<Humano> listahumanos;
    List<Ghoul> listaghouls;
    List<Demonio> listademonios;
    List<String> listabaneados;
    
    
    public BaseDatos(){
      listausuarios=new ArrayList<Usuario>();
      listadisciplinas = new ArrayList<Disciplina>();
      listadones = new ArrayList<Don>();
      listatalentos = new ArrayList<Talento>();
      listafortalezas = new ArrayList<Fortalezas>();
      listadebilidades = new ArrayList<Debilidades>();
      listaArmaduras= new ArrayList<Armadura>();
      listaArmas = new ArrayList<Arma>();
      listaoperadores = new ArrayList<Operador>();
      listahumanos = new ArrayList<Humano>();
      listaghouls = new ArrayList<Ghoul>();
      listademonios = new ArrayList<Demonio>();
      listabaneados = new ArrayList<String>();
    } 
    
    public void Serialize() throws FileNotFoundException, IOException {
        String fic = "D:\\Usuarios.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listausuarios);
        salida.close();
    }
    
    public void Deserialize() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Usuarios.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listausuarios  = (List<Usuario>) entrada.readObject();
    }

    public void SerializeOperador() throws FileNotFoundException, IOException {
        String fic = "D:\\Operadores.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listaoperadores);
        salida.close();
    }
    
    public void DeserializeOperador() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Operadores.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listaoperadores  = (List<Operador>) entrada.readObject();
    }    
    public void SerializeDisciplinas() throws FileNotFoundException, IOException {
        String fic = "D:\\Disciplinas.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listadisciplinas);
        salida.close();
    }
    
    public void DeserializeDisciplinas() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Disciplinas.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listadisciplinas  = (List<Disciplina>) entrada.readObject();
    }
    
    public void SerializeDon() throws FileNotFoundException, IOException {
        String fic = "D:\\Dones.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listadones);
        salida.close();
    }
    
    public void DeserializeDon() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Dones.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listadones  = (List<Don>) entrada.readObject();
    } 
    
    public void SerializeTalento() throws FileNotFoundException, IOException {
        String fic = "D:\\Talentos.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listatalentos);
        salida.close();
    }
    
    public void DeserializeTalento() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Takentos.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listatalentos  = (List<Talento>) entrada.readObject();
    }
    
    public void SerializeFortalezas() throws FileNotFoundException, IOException {
        String fic = "D:\\Fortalezas.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listafortalezas);
        salida.close();
    }
    
    public void DeserializeFortalezas() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Fortalezas.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listafortalezas  = (List<Fortalezas>) entrada.readObject();
    }
    public void SerializeDebilidades() throws FileNotFoundException, IOException {
        String fic = "D:\\Debilidades.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listadebilidades);
        salida.close();
    }
    
    public void DeserializeDebilidades() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Debilidades.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listadebilidades  = (List<Debilidades>) entrada.readObject();
    }       
    
    public void SerializeArmas() throws FileNotFoundException, IOException {
        String fic = "D:\\listaArmas.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listaArmas);
        salida.close();
    }
    
    public void DeserializeArmas() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\listaArmas.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listaArmas  = (List<Arma>) entrada.readObject();
    }
    public void SerializeArmaduras() throws FileNotFoundException, IOException {
        String fic = "D:\\listaArmaduras.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listaArmaduras);
        salida.close();
    }
    
    public void DeserializeArmaduras() throws FileNotFoundException, IOException, ClassNotFoundException{
       String fic = "D:\\listaArmaduras.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listaArmaduras  = (List<Armadura>) entrada.readObject();
    }
    
    public void SerializeHumanos() throws FileNotFoundException, IOException {
        String fic = "D:\\Humanos.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listahumanos);
        salida.close();
    }
    
    public void DeserializeHumanos() throws FileNotFoundException, IOException, ClassNotFoundException{
       String fic = "D:\\Humanos.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listahumanos  = (List<Humano>) entrada.readObject();
    } 
    
    public void SerializeGhouls() throws FileNotFoundException, IOException {
        String fic = "D:\\Ghouls.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listaghouls);
        salida.close();
    }
    
    public void DeserializeGhouls() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Ghouls.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listaghouls = (List<Ghoul>) entrada.readObject();
    }    
    public void SerializeDemonios() throws FileNotFoundException, IOException {
        String fic = "D:\\Demonios.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listademonios);
        salida.close();
    }
    
    public void DeserializeDemonios() throws FileNotFoundException, IOException, ClassNotFoundException{
       String fic = "D:\\Demonios.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listademonios  = (List<Demonio>) entrada.readObject();
    }    
    public void SerializeBaneados() throws FileNotFoundException, IOException {
        String fic = "D:\\Baneados.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listabaneados);
        salida.close();
    }
    
    public void DeserializeBaneados() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Baneados.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listabaneados  = (List<String>) entrada.readObject();
    }    
    
    public List<Usuario> getListausuarios(){
        return listausuarios;
    }
    
    public List<Disciplina> getListaDisciplinas(){
        return listadisciplinas;
    }

    public List<Don> getListaDones() {
        return listadones;
    }

    public List<Talento> getListaTalentos() {
        return listatalentos;
    }

    public List<Fortalezas> getListaFortalezas() {
        return listafortalezas;
    }

    public List<Debilidades> getListaDebilidades() {
        return listadebilidades;
    }

    public List<Armadura> getListaArmaduras() {
        return listaArmaduras;
    }

    public List<Arma> getListaArmas() {
        return listaArmas;
    }

    public List<Operador> getListaoperadores() {
        return listaoperadores;
    }

    public List<Humano> getListahumanos() {
        return listahumanos;
    }

    public List<Ghoul> getListaghouls() {
        return listaghouls;
    }

    public List<Demonio> getListademonios() {
        return listademonios;
    }

    public List<String> getListabaneados() {
        return listabaneados;
    }
        
    public boolean pertenece(String nombre){
        if (this.listausuarios==null){}
        else{
            for(Usuario list: listausuarios){
                if (list.getNombre().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }
    public boolean perteneceBaneado(String nombre){
        if (this.listabaneados==null){}
        else{
            for(String list: listabaneados){
                if (list.equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }    
    
     public Usuario getUsuario(String nombre){
            for(Usuario usuario: listausuarios){
                if (usuario.getNombre().equals(nombre)){
                    return usuario;
                }   
    }return null;
    }

    public Operador getOperador(String nombre){
            for(Operador operador: listaoperadores){
                if (operador.getNombre().equals(nombre)){
                    return operador;
                }   
    }return null;
    }
    public boolean perteneceOperador(String nombre){
        if (this.listaoperadores==null){}
        else{
            for(Operador list: listaoperadores){
                if (list.getNombre().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }
    
    public boolean perteneceDisciplina(String nombre){
        if (this.listadisciplinas==null){}
        else{
            for(Disciplina list: listadisciplinas){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }
    public boolean perteneceDon(String nombre){
        if (this.listadones==null){}
        else{
            for(Don list: listadones){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }   
    public boolean perteneceTalento(String nombre){
        if (this.listatalentos==null){}
        else{
            for(Talento list: listatalentos){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }   

    public boolean perteneceDebilidades(String nombre){
        if (this.listatalentos==null){}
        else{
            for(Debilidades list: listadebilidades){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }
    public boolean perteneceFortalezas(String nombre){
        if (this.listatalentos==null){}
        else{
            for(Fortalezas list: listafortalezas){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }  
    
    public boolean perteneceArma(String nombre){ 
        if (this.listaArmas==null){}
        else{
            for(Arma list: listaArmas){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }
    public boolean perteneceArmadura(String nombre) {
        if (this.listaArmas==null){}
        else{
            for(Arma list: listaArmas){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }
    
    public boolean perteneceHumano(String nombre) {
        if (this.listahumanos==null){}
        else{
            for(Humano list: listahumanos){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    } 
    
    public boolean perteneceGhoul(String nombre) {
        if (this.listaghouls==null){}
        else{
            for(Ghoul list: listaghouls){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    } 
    
    public boolean perteneceDemonio(String nombre) {
        if (this.listademonios==null){}
        else{
            for(Demonio list: listademonios){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }    
    
    public boolean okIni(String nombre, String password){
        for(Usuario list: listausuarios){
            if ((list.getNombre().equals(nombre)) && (list.getPassword().equals(password))){
                return true;
            }   
        }
        return false; 
    }
    public boolean okIniOperador(String nombre, String password){
        for(Operador list: listaoperadores){
            if ((list.getNombre().equals(nombre)) && (list.getPassword().equals(password))){
                return true;
            }   
        }
        return false; 
    }    
}
