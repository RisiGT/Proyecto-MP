/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicamp;

/**
 *
 * @author PcCom
 */
public abstract class Menu {
    public abstract void presentarMenu();
    public abstract void doOperation();
    public void salir(){
        //ns que hacer aqui si abortar programa o volver atras
    }
}
    

