/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package habilidades;

/**
 *
 * @author PcCom
 */
public class Debilidades extends Modificadores {
    private String name;
    private int valor;
    
    public Debilidades(String nombre, int val){
        super(nombre, val);
    }
}
