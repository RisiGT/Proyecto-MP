/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicamp;

import equipo.Arma;
import equipo.Armadura;
import habilidades.Debilidades;
import habilidades.Disciplina;
import habilidades.Don;
import habilidades.Fortalezas;
import habilidades.Talento;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PcCom
 */
public class BaseDatos implements Serializable {
    List<Usuario> listausuarios;
    List<Disciplina> listadisciplinas;
    List<Don> listadones;
    List<Talento> listatalentos;
    List<Fortalezas> listafortalezas;
    List<Debilidades> listadebilidades;
    List<Armadura> listaArmaduras;
    List<Arma> listaArmas;
    
    
    public BaseDatos(){
      listausuarios=new ArrayList<Usuario>();
      listadisciplinas = new ArrayList<Disciplina>();
      listadones = new ArrayList<Don>();
      listatalentos = new ArrayList<Talento>();
      listafortalezas = new ArrayList<Fortalezas>();
      listadebilidades = new ArrayList<Debilidades>();
      listaArmaduras= new ArrayList<Armadura>();
      listaArmas = new ArrayList<Arma>();
    } 
    
    public void Serialize() throws FileNotFoundException, IOException {
        String fic = "D:\\Usuarios.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listausuarios);
        salida.close();
    }
    
    public void Deserialize() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Usuarios.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listausuarios  = (List<Usuario>) entrada.readObject();
    }
    public void SerializeDisciplinas() throws FileNotFoundException, IOException {
        String fic = "D:\\Disciplinas.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listadisciplinas);
        salida.close();
    }
    
    public void DeserializeDisciplinas() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Disciplinas.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listadisciplinas  = (List<Disciplina>) entrada.readObject();
    }
    
    public void SerializeDon() throws FileNotFoundException, IOException {
        String fic = "D:\\Dones.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listadones);
        salida.close();
    }
    
    public void DeserializeDon() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Dones.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listadones  = (List<Don>) entrada.readObject();
    } 
    
    public void SerializeTalento() throws FileNotFoundException, IOException {
        String fic = "D:\\Talentos.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listatalentos);
        salida.close();
    }
    
    public void DeserializeTalento() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Takentos.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listatalentos  = (List<Talento>) entrada.readObject();
    }
    
    public void SerializeFortalezas() throws FileNotFoundException, IOException {
        String fic = "D:\\Fortalezas.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listafortalezas);
        salida.close();
    }
    
    public void DeserializeFortalezas() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Fortalezas.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listafortalezas  = (List<Fortalezas>) entrada.readObject();
    }
    public void SerializeDebilidades() throws FileNotFoundException, IOException {
        String fic = "D:\\Debilidades.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listadebilidades);
        salida.close();
    }
    
    public void DeserializeDebilidades() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\Debilidades.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listadebilidades  = (List<Debilidades>) entrada.readObject();
    }       
    
    public void SerializeArmas() throws FileNotFoundException, IOException {
        String fic = "D:\\listaArmas.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listaArmas);
        salida.close();
    }
    
    public void DeserializeArmas() throws FileNotFoundException, IOException, ClassNotFoundException{
        String fic = "D:\\listaArmas.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listaArmas  = (List<Arma>) entrada.readObject();
    }
    public void SerializeArmaduras() throws FileNotFoundException, IOException {
        String fic = "D:\\listaArmaduras.txt"; //MODIFICAR RUTA
        ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(fic));
        salida.writeObject(this.listaArmaduras);
        salida.close();
    }
    
    public void DeserializeArmaduras() throws FileNotFoundException, IOException, ClassNotFoundException{
       String fic = "D:\\listaArmaduras.txt"; //MODIFICAR RUTA
        ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fic));
        listaArmaduras  = (List<Armadura>) entrada.readObject();
    }
    
    public List<Usuario> getListausuarios(){
        return listausuarios;
    }
    
    public List<Disciplina> getListaDisciplinas(){
        return listadisciplinas;
    }

    public List<Don> getListaDones() {
        return listadones;
    }

    public List<Talento> getListaTalentos() {
        return listatalentos;
    }

    public List<Fortalezas> getListaFortalezas() {
        return listafortalezas;
    }

    public List<Debilidades> getListaDebilidades() {
        return listadebilidades;
    }

    public List<Armadura> getListaArmaduras() {
        return listaArmaduras;
    }

    public List<Arma> getListaArmas() {
        return listaArmas;
    }
        
    public boolean pertenece(String nombre){
        if (this.listausuarios==null){}
        else{
            for(Usuario list: listausuarios){
                if (list.getNombre().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }
    public boolean perteneceDisciplina(String nombre){
        if (this.listadisciplinas==null){}
        else{
            for(Disciplina list: listadisciplinas){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }
    public boolean perteneceDon(String nombre){
        if (this.listadones==null){}
        else{
            for(Don list: listadones){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }   
    public boolean perteneceTalento(String nombre){
        if (this.listatalentos==null){}
        else{
            for(Talento list: listatalentos){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }   

    public boolean perteneceDebilidades(String nombre){
        if (this.listatalentos==null){}
        else{
            for(Debilidades list: listadebilidades){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }
    public boolean perteneceFortalezas(String nombre){
        if (this.listatalentos==null){}
        else{
            for(Fortalezas list: listafortalezas){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }  
    
    public boolean perteneceArma(String nombre){ 
        if (this.listaArmas==null){}
        else{
            for(Arma list: listaArmas){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }
    public boolean perteneceArmadura(String nombre) {
        if (this.listaArmas==null){}
        else{
            for(Arma list: listaArmas){
                if (list.getName().equals(nombre)){
                    return true;
                }   
            }
        }
        return false;
    }
    
    public boolean okIni(String nombre, String password){
        for(Usuario list: listausuarios){
            if ((list.getNombre().equals(nombre)) && (list.getPassword().equals(password))){
                return true;
            }   
        }
        return false; 
    }
}
